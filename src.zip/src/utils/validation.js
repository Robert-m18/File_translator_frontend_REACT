export function validateEmail(email) {
  //regex email validation
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).toLowerCase());
}

export function validatePassword(password) {
  //min 6 chars
  return typeof password === 'string' && password.length >= 6;
}