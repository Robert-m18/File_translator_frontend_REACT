import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const navigate = useNavigate();

  async function handleLogout() {
    setIsLoggingOut(true);
    try {
      // opcjonalnie: wywołaj logout endpoint na backendzie
      // await logoutRequest();

      // Backend usunął HttpOnly cookie, więc wystarczy redirect
      navigate('/');
    } catch (err) {
      console.error('Błąd wylogowania:', err);
    } finally {
      setIsLoggingOut(false);
    }
  }

  return (
    <div className="app">
      <h2>Dashboard</h2>
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <p style={{ fontSize: '18px', marginBottom: '30px' }}>
          ✓ Witamy na stronie głównej! Jesteś zalogowany.
        </p>
        <button
          className="button"
          onClick={handleLogout}
          disabled={isLoggingOut}
        >
          {isLoggingOut ? 'Wylogowywanie...' : 'Wyloguj się'}
        </button>
      </div>
    </div>
  );
}

