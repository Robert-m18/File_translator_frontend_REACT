import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { validateEmail, validatePassword } from '../utils/validation';
import { loginRequest } from '../api/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [serverMessage, setServerMessage] = useState(null);
  const navigate = useNavigate();

  function validate() {
    const e = {};
    if (!validateEmail(email)) e.email = 'Niepoprawny adres e-mail';
    if (!validatePassword(password)) e.password = 'Hasło musi mieć co najmniej 6 znaków';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    setServerMessage(null);
    if (!validate()) return;

    try {
      await loginRequest({ email, password });
      setServerMessage({ type: 'success', text: 'Zalogowano pomyślnie' });
      // redirect po 1s żeby użytkownik zobaczył komunikat
      setTimeout(() => navigate('/dashboard'), 1000);
    } catch (err) {
      setServerMessage({ type: 'error', text: err.message || 'Błąd logowania' });
    }
  }

  return (
    <div className="app">
      <h2>Logowanie</h2>
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div>
          <input
            className="input"
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
          {errors.email && <div className="error">{errors.email}</div>}
        </div>

        <div>
          <input
            className="input"
            type="password"
            placeholder="Hasło"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
          {errors.password && <div className="error">{errors.password}</div>}
        </div>

        <button className="button" type="submit">Zaloguj</button>
      </form>

      {serverMessage && (
        <div className={serverMessage.type === 'error' ? 'error' : 'success'}>
          {serverMessage.text}
        </div>
      )}

      <p>
        Nie masz konta? <Link to="/register">Zarejestruj się</Link>
      </p>
    </div>
  );
}