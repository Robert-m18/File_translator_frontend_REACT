import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { validateEmail, validatePassword } from '../utils/validation';
import { registerRequest, loginRequest } from '../api/auth';

export default function Register() {
  const [serverMessage, setServerMessage] = useState(null);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm();

  const password = watch('password');

  async function onSubmit(data) {
    setServerMessage(null);
    try {
      // rejestracja
      await registerRequest({ name: data.name, email: data.email, password: data.password });

      // po rejestracji zaraz zaloguj
      await loginRequest({ email: data.email, password: data.password });

      setServerMessage({ type: 'success', text: 'Rejestracja i logowanie udane!' });
      // redirect po 1s
      setTimeout(() => navigate('/dashboard'), 1000);
    } catch (err) {
      setServerMessage({ type: 'error', text: err.message || 'Błąd rejestracji' });
    }
  }

  return (
    <div className="app">
      <h2>Rejestracja</h2>
      <form className="form" onSubmit={handleSubmit(onSubmit)} noValidate>
        <div>
          <input
            className="input"
            type="text"
            placeholder="Imię"
            {...register('name', {
              required: 'Podaj imię (min. 2 znaki)',
              minLength: { value: 2, message: 'Podaj imię (min. 2 znaki)' },
            })}
          />
          {errors.name && <div className="error">{errors.name.message}</div>}
        </div>

        <div>
          <input
            className="input"
            type="email"
            placeholder="Email"
            {...register('email', {
              required: 'Niepoprawny adres e-mail',
              validate: value => validateEmail(value) || 'Niepoprawny adres e-mail',
            })}
          />
          {errors.email && <div className="error">{errors.email.message}</div>}
        </div>

        <div>
          <input
            className="input"
            type="password"
            placeholder="Hasło"
            {...register('password', {
              required: 'Hasło musi mieć co najmniej 6 znaków',
              validate: value => validatePassword(value) || 'Hasło musi mieć co najmniej 6 znaków',
            })}
          />
          {errors.password && <div className="error">{errors.password.message}</div>}
        </div>

        <div>
          <input
            className="input"
            type="password"
            placeholder="Powtórz hasło"
            {...register('password2', {
              required: 'Hasła nie są takie same',
              validate: value => value === password || 'Hasła nie są takie same',
            })}
          />
          {errors.password2 && <div className="error">{errors.password2.message}</div>}
        </div>

        <button className="button" type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Rejestrowanie...' : 'Zarejestruj'}
        </button>
      </form>

      {serverMessage && (
        <div className={serverMessage.type === 'error' ? 'error' : 'success'}>
          {serverMessage.text}
        </div>
      )}

      <p>
        Masz konto? <Link to="/">Zaloguj się</Link>
      </p>
    </div>
  );
}