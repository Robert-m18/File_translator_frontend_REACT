const API_BASE = 'http://localhost:2009';

async function safeFetch(url, opts) {
  try {
    return await fetch(url, opts);
  } catch (err) {
    // fetch throws on network errors — normalize to Error and return a rejected promise
    return Promise.reject(new Error(err.message || 'Błąd połączenia z serwerem'));
  }
}

export async function loginRequest({ email, password }) {
  const res = await safeFetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ email, password })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText || 'Błąd serwera' }));
    throw new Error(err.message || 'Błąd logowania');
  }

  return res.json();
}

export async function registerRequest({ name, email, password }) {
  const res = await safeFetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ name, email, password })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText || 'Błąd serwera' }));
    throw new Error(err.message || 'Błąd rejestracji');
  }

  return res.json();
}